package COIL_VIC_LOGIC.Classes;

public class Student {
    private String email;

    public Student() {
      
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
