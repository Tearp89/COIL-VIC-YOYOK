package COIL_VIC_LOGIC.Classes;

public class University {
    private String universityId;
    private String universityName;
    private String universityCountry;
    private String universityLanguage;
    
    public University() {
      
    }

    public String getUniversityId() {
        return universityId;
    }

    public void setUniversityId(String universityId) {
        this.universityId = universityId;
    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public String getUniversityCountry() {
        return universityCountry;
    }

    public void setUniversityCountry(String universityCountry) {
        this.universityCountry = universityCountry;
    }

    public String getUniversityLanguage() {
        return universityLanguage;
    }

    public void setUniversityLanguage(String universityLanguage) {
        this.universityLanguage = universityLanguage;
    }
    



}
