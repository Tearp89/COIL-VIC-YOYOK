package COIL_VIC_LOGIC.Interfaces;
import COIL_VIC_LOGIC.Classes.Student;

public interface IStudent {
    int addStudent(Student student);
}
