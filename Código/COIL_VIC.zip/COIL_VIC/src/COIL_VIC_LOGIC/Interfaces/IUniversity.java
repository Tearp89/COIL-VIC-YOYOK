package COIL_VIC_LOGIC.Interfaces;
import COIL_VIC_LOGIC.Classes.University;


public interface IUniversity {
    int addUniversity(University university);
    int deleteUniversity(University university);
    int updateUniversity(University university);
}
