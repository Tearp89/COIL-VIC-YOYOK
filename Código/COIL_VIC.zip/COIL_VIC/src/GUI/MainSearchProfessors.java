package GUI;

public class MainSearchProfessors {

}
