package logic.interfaces;
import logic.classes.Student;

public interface IStudent {
    int addStudent(Student student);
}
