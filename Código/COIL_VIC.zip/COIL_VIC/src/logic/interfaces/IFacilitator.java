/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package logic.interfaces;

import logic.classes.Facilitator;

/**
 *
 * @author isabe
 */
public interface IFacilitator {
    int addFacilitator(Facilitator facilitatot);
    int deleteFacilitator(Facilitator facilitator);
    int updateFacilitator(Facilitator facilitator);
}
