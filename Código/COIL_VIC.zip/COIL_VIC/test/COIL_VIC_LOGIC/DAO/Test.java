package COIL_VIC_LOGIC.DAO;

public @interface Test {

}
