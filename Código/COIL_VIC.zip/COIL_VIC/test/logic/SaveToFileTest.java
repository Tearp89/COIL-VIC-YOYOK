/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package logic;

import javafx.scene.control.TableView;
import javax.swing.JTable;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 *
 * @author daur0
 */
public class SaveToFileTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }


    /**
     * Test of exportExcel method, of class SaveToFile.
     */
    @Test
    public void testExportExcel() throws Exception {
        
    }

    /**
     * Test of exportTableToExcel method, of class SaveToFile.
     */
    @Test
    public void testExportTableToExcel() {
        
    }
    
}
